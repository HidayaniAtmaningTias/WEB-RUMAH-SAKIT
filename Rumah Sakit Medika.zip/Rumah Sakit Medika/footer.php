<!-- FOOTER -->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-4">
			<h3><span class="glyphicon glyphicon-bullhorn"></span> Berita Terbaru</h3>
				<ul class="list-group">
					<li class="list-group-item"><a href="#">Mayat yang terkubur sendiri</a></li>
					<li class="list-group-item"><a href="#">Kecelakaan paling parah se indonesia</a></li>
					<li class="list-group-item"><a href="#">Dokter muda kaya raya</a></li>
				</ul>
				
			</div>
			<div class="col-md-4">
			<h3><span class="glyphicon glyphicon-info-sign"></span> Informasi Rumah sakit</h3>
				<ul class="list-group">
					<li class="list-group-item"><a href="#">Pendaftaran untuk beasiswa dokter 2024 telah dibuka</a></li>
					<li class="list-group-item"><a href="#">Semua dokter wajib memiiki gelar</a></li>
					<li class="list-group-item"><a href="#">Apapun yang terjadi tetap harus menyelamatkan pasien</a></li>
				</ul>
				
			</div>
			<div class="col-md-4">
			<h3><span class="glyphicon glyphicon-link"></span>Link paling bagus</h3>
				<ul class="list-group">
					<li class="list-group-item"><a href="#">Seputar penyakit langka</a></li>
					<li class="list-group-item"><a href="#">Obat mujarab</a></li>
					<li class="list-group-item"><a href="#">Dokter cinta</a></li>
					<li class="list-group-item"><a href="#">Semua ada disini</a></li>
				</ul>
				
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<center>Rumah Sakit Medika<span class="glyphicon glyphicon-heart"></span> by Tyas Atmaning<br/>
				</center>
			</div>
			</div>
	</div><!-- Akhir FOOTER -->
		
	<script src="bootstrap/js/jquery.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script src="bootstrap/js/dataTables.bootstrap.min.js"></script>
	<script src="bootstrap/js/jquery.dataTables.js"></script>
	<script src="bootstrap/js/scripts.js"></script>
	</body>
</html>