
















<div class="row">
      <div class="panel panel-default">
        <div class="panel-body">
        <h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> Fasilitas Rumah Sakit</h2>
        
        <p>Rumah Sakit Medika Jl Cinta No.767 Aek kenopan ,Labuhan batu utara, Sumatera Utara(061-735367)</p>
        
        <div class="row">
          <div class="col-md-3">
          <h3>RUANG OPERASI LENGKAP</h3>
            <img src="images/operasi.jpg" class="img-thumbnail img-responsive">
            <p>Walaupun ini adalah rumah sakit gratis,tetapi tetap mempunyai ruag operasi yang lengkap dan tetap memiliki peralatan yg terbilang mumpuni.<br/></p>
          </div>
          <div class="col-md-3">
          <h3>KURSI RODA SUPER</h3>
            <img src="images/kurod.jpg" class="img-thumbnail img-responsive">
            <p>Bagi pasien yang sudah tidak sanggup untuk jalan,Rumah sakit Medika juga menyediakan Kursi roda super yang dapat menghantarkan pasien keruang operasi menggunakan remote.<br/></p>
          </div>
          <div class="col-md-3">
          <h3>AMBULANCE RODA 6</h3>
            <img src="images/ambulan.jpg" class="img-thumbnail img-responsive">
            <p>Jika dalam keadaan mendesak atau mengharuskan pasien dijemput ke suatu tempat,Rumah sakit Medika juga bisa menggunakan fasilitas yg lainnya yaitu Ambulance roda 6 yang mampu berkendara dengan cepat dan aman.<br/></p>
          </div>
          <div class="col-md-3">
          <h3>TANDU</h3>
            <img src="images/tandu.jpg" class="img-thumbnail img-responsive">
            <p>Ketika ada pasien yang naik ambulance maka akan langsung dikeluaran menggunakan tandu agar pasien tetap dalam keadaan baik pada saat sampai dirumah sakit.<br/></p>
          </div>
        </div>
      
        </div>
      </div>
    </div>