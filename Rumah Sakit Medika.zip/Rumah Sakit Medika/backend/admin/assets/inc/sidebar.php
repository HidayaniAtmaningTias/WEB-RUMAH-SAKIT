<div class="left-side-menu">

                <div class="slimscroll-menu">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">

                        <ul class="metismenu" id="side-menu">

                            <li class="menu-title">Navigation</li>

                            <li>
                                <a href="his_admin_dashboard.php">
                                    <i class="fe-airplay"></i>
                                    <span> Dashboard </span>
                                </a>
                                
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fab fa-accessible-icon "></i>
                                    <span> Pasien </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_register_patient.php">Registrasi Pasien</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_view_patients.php">Lihat Pasien</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_patient.php">Kelola Pasien</a>
                                    </li>
                                    <hr>
                                    
                                </ul>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="mdi mdi-doctor"></i>
                                    <span> Karyawan </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_add_employee.php">Tambah Karyawan</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_view_employee.php">Lihat Karyawan</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_employee.php">Kelola Karyawan</a>
                                    </li>
                                    <hr>
                                    <li>
                                        <a href="his_admin_assaign_dept.php">Departemen</a>
                                    </li>
                                    
                                </ul>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="mdi mdi-pill"></i>
                                    <span> Farmasi </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    
                                    
                                    
                                    <hr>
                                    <li>
                                        <a href="his_admin_add_pharmaceuticals.php">Tambah Obat</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_view_pharmaceuticals.php">Lihat Obat</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_pharmaceuticals.php">Kelola Obat</a>
                                    </li>
                                    <hr>
                                    
                                    
                                    
                                </ul>
                            </li>

                            
                            <li>
                                <a href="javascript: void(0);">
                                    <i class=" fas fa-funnel-dollar "></i>
                                    <span> Inventaris </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                   
                                    <li>
                                        <a href="his_admin_pharm_inventory.php">Pharmaceuticals</a>
                                    </li>

                                    <li>
                                        <a href="his_admin_equipments_inventory.php">Assets</a>
                                    </li>
                                    
                                </ul>
                            </li>
                
                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-share"></i>
                                    <span> Reporting </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_inpatient_records.php">Catatan Pasien Masuk</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_outpatient_records.php">Catatan Pasien Keluar</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_employee_records.php">Catatan Karyawan</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_pharmaceutical_records.php">Catatan Pharmaceutical</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_medical_records.php">Catatan Medis</a>
                                    </li>
                                    
                                </ul>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-file-text"></i>
                                    <span> Medical Records </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_add_medical_record.php">Tambah Catatan Medis</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_medical_record.php">Kelola Catatan Medis</a>
                                    </li>
                                    
                                </ul>
                            </li>

                            

                            

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="mdi mdi-cash-refund "></i>
                                    <span> Daftar Gaji Karyawan </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_add_payroll.php">Tambah Daftar Gaji</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_payrolls.php">Kelola Daftar Gaji</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_generate_payrolls.php">Lihat Gaji Karyawan</a>
                                    </li>
                                </ul>
                            </li>

                                                                        
                                </ul>
                            </li>

                        </ul>

                    </div>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>