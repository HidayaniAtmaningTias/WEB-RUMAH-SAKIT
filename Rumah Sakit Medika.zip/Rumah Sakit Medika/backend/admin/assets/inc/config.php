<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="rsdb";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>
