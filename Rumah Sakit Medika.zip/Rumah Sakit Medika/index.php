<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Page Title -->
    <title>Sistem Manajemen Rumah Sakit</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/logo/logo.jpg" type="image/x-icon">

    <!-- CSS Files -->
    <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/selengkapnya.php">
</head>
<body>
    <!-- Preloader Starts -->
    <div class="preloader">
        <div class="spinner"></div>
    </div>
    <!-- Preloader End -->

    <!-- Header Area Starts -->
    <header class="header-area">
        <div id="header" id="home">
            <div class="container">
                <div class="row align-items-center justify-content-between d-flex">
                <div id="logo">
                    <a href="index.php"></a>
                </div>
                <nav id="nav-menu-container">
                    <ul class="nav-menu">
                        <li class="menu-active"><a href="index.php">Home</a></li>
                        <li><a href="backend/admin/index.php">Login Admin</a></li>
                    </ul>
                </nav><!-- #nav-menu-container -->		    		
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Banner Area Starts -->
    <section class="banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <h4>Merawat  anda tentu kehidupan sangat menyenangkan</h4>
                    
                    <p>Rumah sakit dianugerahi sebagai salah satu Sistem Manajemen Rumah Sakit Terbaik, yang dapat mengintegrasikan semua sistem dan proses, istem informasi cerdas untuk memperoleh efisiensi operasional dan membantu rumah sakit dalam proses pengambilan keputusan melalui MIS dan Analitik.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Awal Page -->
    <div class="container">
    <!-- Awal Panel -->
    <div class="row">
      <div class="panel panel-default">
        <div class="panel-body">
        <h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> Fasilitas Rumah Sakit</h2>
        
        <p>Rumah Sakit Medika Jl Cinta No.767 Aek kenopan ,Labuhan batu utara, Sumatera Utara(061-735367)</p>
        
        <div class="row">
          <div class="col-md-3">
          <h3>RUANG OPERASI LENGKAP</h3>
            <img src="images/operasi.jpg" class="img-thumbnail img-responsive">
            <p>Walaupun ini adalah rumah sakit gratis,tetapi tetap mempunyai ruag operasi yang lengkap dan tetap memiliki peralatan yg terbilang mumpuni.<br/><a class="btn btn-danger btn-xs" href="selengkapnya.php"role="button">Selengkapnya</a></p>
          </div>
          <div class="col-md-3">
          <h3>KURSI RODA SUPER</h3>
            <img src="images/kurod.jpg" class="img-thumbnail img-responsive">
            <p>Bagi pasien yang sudah tidak sanggup untuk jalan,Rumah sakit Medika juga menyediakan Kursi roda super yang dapat menghantarkan pasien keruang operasi menggunakan remote.<br/><a class="btn btn-info btn-xs" href="selengkapnya.php"role="button">Selengkapnya</a></p>
          </div>
          <div class="col-md-3">
          <h3>AMBULANCE RODA 6</h3>
            <img src="images/ambulan.jpg" class="img-thumbnail img-responsive">
            <p>Jika dalam keadaan mendesak atau mengharuskan pasien dijemput ke suatu tempat,Rumah sakit Medika juga bisa menggunakan fasilitas yg lainnya yaitu Ambulance roda 6 yang mampu berkendara dengan cepat dan aman.<br/><a class="btn btn-success btn-xs" href="laboratorium.php"role="button">Selengkapnya</a></p>
          </div>
          <div class="col-md-3">
          <h3>TANDU</h3>
            <img src="images/tandu.jpg" class="img-thumbnail img-responsive">
            <p>Ketika ada pasien yang naik ambulance maka akan langsung dikeluaran menggunakan tandu agar pasien tetap dalam keadaan baik pada saat sampai dirumah sakit.<br/><a class="btn btn-warning btn-xs" href="internet_cafe.php"role="button">Selengkapnya</a></p>
          </div>
        </div>
      
        </div>
      </div>
    </div><!-- Akhir Panel -->
  
        </div>
        </div>
      </div>
    </div><!-- Akhir Panel -->
    </div><!--  Akhir Page -->
<?php include "footer.php"; ?>


    <!-- Javascript -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
	<script src="assets/js/vendor/bootstrap-4.1.3.min.js"></script>
    <script src="assets/js/vendor/wow.min.js"></script>
    <script src="assets/js/vendor/owl-carousel.min.js"></script>
    <script src="assets/js/vendor/jquery.datetimepicker.full.min.js"></script>
    <script src="assets/js/vendor/jquery.nice-select.min.js"></script>
    <script src="assets/js/vendor/superfish.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>
